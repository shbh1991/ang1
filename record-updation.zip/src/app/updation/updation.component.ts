import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-record-updation',
  templateUrl: './updation.component.html',
  styleUrls: ['./updation.component.scss']
})
export class UpdationComponent implements OnInit {
  constructor() { }
  ngOnInit() {

  }
}

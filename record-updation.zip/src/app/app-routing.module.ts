import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { FormPageComponent } from './form-page/form-page.component';

const routes: Routes = [
  { path: "", component: WelcomePageComponent },
  { path: "homepage", component: WelcomePageComponent },
  { path: "add-records", component: FormPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { initialNavigation: false })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

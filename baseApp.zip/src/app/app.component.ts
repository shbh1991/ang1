import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  showR: boolean = true; addR: boolean = false;
  title = 'Micro FrontEnd Application';
  showRecords() {
    this.showR = true;
    this.addR = false;
  }
  addRecords() {
    this.showR = false;
    this.addR = true;
  }
}
